﻿using System.ComponentModel.DataAnnotations;

namespace PetShop.Models
{
    public class Animal
    {
        public int AnimalId { get; set; }
        [Required(ErrorMessage = "Animal Name is required")]
        [RegularExpression("[A-Za-z]+", ErrorMessage = "Only letters are allowed")]
        [MaxLength(20, ErrorMessage = "Animal Name must be at most 20 characters")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Animal Age is required")]
        [Range(0.01, 10000, ErrorMessage = "Animal Age must be between 0.01 and 10000")]
        public int Age { get; set; }
        public string? PictureName { get; set; }
        [Display(Name = "Animal Description: ")]
        [Required]
        [DataType(DataType.MultilineText)]
        public string? Description { get; set; }
        [Required(ErrorMessage = "Category is required")]
        public int CategoryId { get; set; }
        public virtual Category? Category { get; set; }
        public virtual ICollection<Comment>? Comment { get; set; } = new List<Comment>();

    }
}
