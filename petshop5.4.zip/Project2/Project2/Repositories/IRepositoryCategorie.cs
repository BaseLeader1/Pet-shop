﻿using PetShop.Models;

namespace PetShop.Repositories
{
    public interface IRepositoryCategorie
    {
        IEnumerable<Category> GetCategorie();


    }
}
