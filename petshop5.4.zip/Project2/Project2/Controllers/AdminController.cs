﻿using Microsoft.AspNetCore.Mvc;
using PetShop.Models;
using PetShop.Repositories;


namespace PetShop.Controllers
{
    public class AdminController : Controller
    {
        private IRepositoryCategorie _repositoryCategorie;
        private IRepositoryAnimal _animalRepository;
        private IRepositoryComment _commentRepository;
        private IWebHostEnvironment _webHostEnvironment;
        public AdminController(IRepositoryCategorie repositoryCategorie, IRepositoryAnimal repositoryAnimal, IRepositoryComment commentRepository, IWebHostEnvironment webHostEnvironment)
        {
            _repositoryCategorie = repositoryCategorie;
            _animalRepository = repositoryAnimal;
            _commentRepository = commentRepository;
            _webHostEnvironment = webHostEnvironment;
        }
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.animals = _animalRepository.GetAnimal();
            return View(_repositoryCategorie.GetCategorie());
        }
        [HttpPost]
        public IActionResult Index(int _categoryId)
        {
            if (_categoryId == 0)
            {
                ViewBag.animals = _animalRepository.GetAnimal();
            }
            else
            {
                ViewBag.animals = _animalRepository.GetAnimal().Where(a => a.CategoryId == _categoryId);
            }
            return View(_repositoryCategorie.GetCategorie());
        }
        [HttpGet]
        public IActionResult Insert()
        {
            ViewBag.CategoryList = _repositoryCategorie.GetCategorie();
            return View();
        }
        [HttpPost]
        public IActionResult Insert(string Name, int Age, int CategoryId, string DescriptionText, IFormFile PictureFile)
        {
            var fileExtension = Path.GetExtension(PictureFile.FileName);
            var filename = $"{Name}{fileExtension}";
            var filepath = Path.Combine(_webHostEnvironment.WebRootPath, "source", filename);
            using (var fileStream = new FileStream(filepath, FileMode.Create))
            {
                PictureFile.CopyTo(fileStream);
            }
            var _animal = new Animal
            {
                Name = Name,
                Age = Age,
                PictureName = filename,
                Description = DescriptionText,
                CategoryId = CategoryId
            };
            _animalRepository.InsertAnimals(_animal);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult UpdateAnimal(int _animalId)
        {
            ViewBag.CategoryList = _repositoryCategorie.GetCategorie();
            return View(_animalRepository.GetAnimal().Where(a => a.AnimalId == _animalId).FirstOrDefault());
        }
        [HttpPost]
        public IActionResult UpdateAnimal(string Name, int animalId, int Age, int CategoryId, string DescriptionText, IFormFile PictureFile)
        {
            var fileExtension = Path.GetExtension(PictureFile.FileName);
            var filename = Guid.NewGuid().ToString() + $"{Name}{fileExtension}";
            var filepath = Path.Combine(_webHostEnvironment.WebRootPath, "source", filename);
            using (var fileStream = new FileStream(filepath, FileMode.Create))
            {
                PictureFile.CopyTo(fileStream);
            }
            var _animal = new Animal
            {
                Name = Name,
                Age = Age,
                PictureName = filename,
                Description = DescriptionText,
                CategoryId = CategoryId
            };
            _animalRepository.UpdateAnimals(animalId, _animal);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult DeleteAnimal(int _animalId)
        {
            _commentRepository.DeleteComment(_animalId);
            _animalRepository.DeleteAnimals(_animalId);
            return RedirectToAction("Index");
        }
    }
}
